(function () {

    setTimeout(function () {
        var images = null;

        var shopTab = document.getElementById('shopTab');
        if ((shopTab != null)&& (shopTab.children != null)) {
            images = shopTab.children;
            // selected
            images[0].src = 'https://i.imgur.com/2qFpkHm.png';
            images[0].setAttribute('srcset', 'https://i.imgur.com/1fo1swc.png 2x');
            // deselected
            images[1].src = 'https://i.imgur.com/eh54AM5.png';
            images[1].setAttribute('srcset', 'https://i.imgur.com/ii1hiDi.png 2x');
        }

        var newsTab = document.getElementById('newsTab');
        if ((newsTab != null) && (newsTab.children != null)) {
            images = newsTab.children;
            // selected
            images[0].src = 'https://i.imgur.com/nY24pGb.png';
            images[0].setAttribute('srcset', 'https://i.imgur.com/TdUMEub.png 2x');
            // deselected
            images[1].src = 'https://i.imgur.com/P9GNdLY.png';
            images[1].setAttribute('srcset', 'https://i.imgur.com/2Lxx97q.png 2x');
        }

        var gameTab = document.getElementById('gameTab');
        if ((gameTab != null) && (gameTab.children != null)) {
            images = gameTab.children;
            // selected
            images[0].src = 'https://i.imgur.com/Cm3LdpY.png';
            images[0].setAttribute('srcset', 'https://i.imgur.com/iNJkC5K.png 2x');
            // deselected
            images[1].src = 'https://i.imgur.com/3arvoW6.png';
            images[1].setAttribute('srcset', 'https://i.imgur.com/fh8BsBn.png 2x');
        }

        var forumTab = document.getElementById('forumTab');
        if ((forumTab != null) && (forumTab.children != null)) {
            images = forumTab.children;
            // selected
            images[0].src = 'https://i.imgur.com/QJFYaoc.png';
            images[0].setAttribute('srcset', 'https://i.imgur.com/7UHh4qx.png 2x');
            // deselected
            images[1].src = 'https://i.imgur.com/pNwyIh4.png';
            images[1].setAttribute('srcset', 'https://i.imgur.com/xE0cmuS.png 2x');
        }

        var garageTab = document.getElementById('garageTab');
        if ((garageTab != null) && (garageTab.children != null)) {
            images = garageTab.children;
            // selected
            images[0].src = 'https://i.imgur.com/feqLi7b.png';
            images[0].setAttribute('srcset', 'https://i.imgur.com/yq8g7r9.png 2x');
            // deselected
            images[1].src = 'https://i.imgur.com/kzaSP75.png';
            images[1].setAttribute('srcset', 'https://i.imgur.com/aRgI9y4.png 2x');
        }

        var appStoreSnippet = document.getElementById('appStoreSnippet');
        if (appStoreSnippet != null) {
            var imgAppStore = appStoreSnippet.children[0];
            imgAppStore.src = 'https://vectr.com/commanderanime/e4j7fvcqk5.svg?width=640&height=186.67&select=e4j7fvcqk5page0';
        }

        var googlePlaySnippet = document.getElementById('googlePlaySnippet');
        if (googlePlaySnippet != null) {
            var imgGooglePlay = googlePlaySnippet.children[0];
            imgGooglePlay.src = 'https://vectr.com/commanderanime/c23SvBkgX7.svg?width=640&height=213.33&select=c23SvBkgX7page0';
        }
    }, 400);

    function localTabImages() {
        setTimeout(function () {
            var newsPost54 = document.getElementById('newsPost-54');

            if (newsPost54 != null) {
                var imgNewsPost = newsPost54.getElementsByTagName('img')[1];
                imgNewsPost.src = 'https://i.imgur.com/h9iV4He.png';
                imgNewsPost.setAttribute('srcset', 'https://i.imgur.com/4lgXMG3.png 2x');
            }

            var newsPost29 = document.getElementById('newsPost-29');
            if (newsPost29 != null) {
                var imgNewsPost = newsPost29.getElementsByTagName('img')[1];
                imgNewsPost.src = 'https://i.imgur.com/IyPANd4.png';
                imgNewsPost.setAttribute('srcset', 'https://i.imgur.com/0Qt72LN.png 2x');
            }

            var newsPost39 = document.getElementById('newsPost-39');
            if (newsPost39 != null) {
                var imgNewsPost = newsPost39.getElementsByTagName('img')[1];
                imgNewsPost.src = 'https://i.imgur.com/IyPANd4.png';
                imgNewsPost.setAttribute('srcset', 'https://i.imgur.com/0Qt72LN.png 2x');
            }

            var newsPost25 = document.getElementById('newsPost-25');
            if (newsPost25 != null) {
                var content = newsPost25.getElementsByClassName('content')[0];
                content.style.backgroundImage = "url('https://i.imgur.com/Q0VBA0I.png')";


            }

            var threadsWrapper = document.getElementById('threadsWrapper');
            if (threadsWrapper != null) {
                var ellipsis = threadsWrapper.getElementsByClassName('ellipsis');
                if ((ellipsis != null) && (ellipsis.length) && (ellipsis.length > 0)) {
                    for (var i = 0; i < ellipsis.length; i++) {
                        var ellipsisImage = ellipsis[i].children[0];
                        ellipsisImage.src = 'https://i.imgur.com/pBtVKL2.png';
                        ellipsisImage.setAttribute('srcset', 'https://i.imgur.com/T3cQP4b.png 2x');
                    }
                }

                var others = threadsWrapper.getElementsByClassName('other');
                if ((others != null) && (others.length) && (others.length > 0)) {
                    for (i = 0; i < others.length; i++) {
                        var otherChildren = others[i].children;
                        if ((otherChildren != null) && (otherChildren.length) && (otherChildren.length > 0)) {
                            for (var j = 0; j < otherChildren.length; j++) {
                                var childImages = null;
                                var childDiv = otherChildren[j];
                                if (childDiv.getAttribute("class").indexOf('selected') != -1) {
                                    childImages = childDiv.getElementsByTagName('img');
                                    if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                        for (var k = 0; k < childImages.length; k++) {


                                        }
                                    }
                                }
                                else {
                                    childImages = childDiv.getElementsByTagName('img');
                                    if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                        for (var k = 0; k < childImages.length; k++) {
                                            var buttonImage = childImages[k];
                                            if (buttonImage.src.indexOf('page0') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/xyHsbDk.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/HTmeB5H.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/loGYUlS.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/vPtQEjp.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/U7ZteJs.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/8UR9Yhn.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/bBzcVyr.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/RBoTXTL.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page1') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/E6tLMed.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/muPaovt.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/vYaBHHh.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/99VMjsw.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/0pLCCmB.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/ZYXRnmk.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/pDCV4gA.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/E7UJbND.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page2') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/TBhi5To.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/TXROBO3.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/9hJDNVD.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/XjaCElo.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/X9CD9wa.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/VmiauL2.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/c1YQ9SQ.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/140z8UJ.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page3') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/0hyAkOU.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/nR4YZi8.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/hhqTHip.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/hOl39Vq.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/FNX1xQJ.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/hKcq360.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/oVGawRo.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/hYJkxpT.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page4') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/3keYJWh.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/YLiBU5R.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/yXpY9j5.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/gScdzjm.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/9ajtmom.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/tMldxmT.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/eE7KOEv.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/0crvRhc.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page5') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/1lWBjDE.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/9zC41E2.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/JLl9PsD.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/l5nwC1m.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/eQTSAI4.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/BgxNpbQ.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/ZPJDx7H.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/DHV3qOZ.png 2x');
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                var newest = threadsWrapper.getElementsByClassName('newest');
                if ((newest != null) && (newest.length) && (newest.length > 0)) {
                    for (i = 0; i < newest.length; i++) {
                        var newestChild = newest[i];
                        if ((newestChild != null) && (newestChild.children)) {
                            var childImages = newestChild.children;
                            if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                for (var k = 0; k < childImages.length; k++) {
                                    var buttonImage = childImages[k];
                                    if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/gt0tVDJ.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/W3fuz9v.png 2x');
                                    }
                                    else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/lccL9Lf.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/perrYx0.png 2x');
                                    }
                                    else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/uKi5wUE.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/jAtP5aA.png 2x');
                                    }
                                    else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/VczR3zU.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/348mgw6.png 2x');
                                    }
                                }
                            }
                        }
                    }
                }

            }

            var repliesWrapper = document.getElementById('repliesWrapper');
            if (repliesWrapper != null) {
                var backButton = repliesWrapper.getElementsByClassName('back');
                if ((backButton != null) && (backButton.length) && (backButton.length > 0)) {
                    for (var i = 0; i < backButton.length; i++) {
                        var childImages = backButton[i].children;
                        if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                            for (var j = 0; j < childImages.length; j++) {
                                var image = childImages[j];
                                if (image.getAttribute("class").indexOf('standard') != -1) {
                                    image.src = 'https://i.imgur.com/mSo1QGD.png';
                                    image.setAttribute('srcset', 'https://i.imgur.com/3M7wayz.png 2x');
                                }
                                else if (image.getAttribute("class").indexOf('active') != -1) {
                                    image.src = 'https://i.imgur.com/6dflRS5.png';
                                    image.setAttribute('srcset', 'https://i.imgur.com/2GZxqBL.png 2x');
                                }
                            }
                        }
                    }
                }

                var oldestButton = repliesWrapper.getElementsByClassName('oldest');
                if ((oldestButton != null) && (oldestButton.length) && (oldestButton.length > 0)) {
                    for (var i = 0; i < oldestButton.length; i++) {
                        var childImages = oldestButton[i].children;
                        if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                            for (var j = 0; j < childImages.length; j++) {
                                var image = childImages[j];
                                if (image.getAttribute("class").indexOf('selected active') != -1) {
                                    image.src = 'https://i.imgur.com/R8p4OFE.png';
                                    image.setAttribute('srcset', 'https://i.imgur.com/KYhm3ej.png 2x');
                                }
                                else if (image.getAttribute("class").indexOf('standard') != -1) {
                                    image.src = 'https://i.imgur.com/TKEmqY6.png';
                                    image.setAttribute('srcset', 'https://i.imgur.com/VolrKCn.png 2x');
                                }
                                else if (image.getAttribute("class").indexOf('active') != -1) {
                                    image.src = 'https://i.imgur.com/r3oXJXI.png';
                                    image.setAttribute('srcset', 'https://i.imgur.com/sN4CVCF.png 2x');
                                }
                                else if (image.getAttribute("class").indexOf('selected') != -1) {
                                    image.src = 'https://i.imgur.com/3ErO44k.png';
                                    image.setAttribute('srcset', 'https://i.imgur.com/b1wgI58.png 2x');
                                }
                            }
                        }
                    }
                }

                var ellipsis = repliesWrapper.getElementsByClassName('ellipsis');
                if ((ellipsis != null) && (ellipsis.length) && (ellipsis.length > 0)) {
                    for (var i = 0; i < ellipsis.length; i++) {
                        var ellipsisImage = ellipsis[i].children[0];
                        ellipsisImage.src = 'https://i.imgur.com/pBtVKL2.png';
                        ellipsisImage.setAttribute('srcset', 'https://i.imgur.com/T3cQP4b.png 2x');
                    }
                }

                var others = repliesWrapper.getElementsByClassName('other');
                if ((others != null) && (others.length) && (others.length > 0)) {
                    for (i = 0; i < others.length; i++) {
                        var otherChildren = others[i].children;
                        if ((otherChildren != null) && (otherChildren.length) && (otherChildren.length > 0)) {
                            for (var j = 0; j < otherChildren.length; j++) {
                                var childImages = null;
                                var childDiv = otherChildren[j];
                                if (childDiv.getAttribute("class").indexOf('selected') != -1) {
                                    childImages = childDiv.getElementsByTagName('img');
                                    if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                        for (var k = 0; k < childImages.length; k++) {


                                        }
                                    }
                                }
                                else {
                                    childImages = childDiv.getElementsByTagName('img');
                                    if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                        for (var k = 0; k < childImages.length; k++) {
                                            var buttonImage = childImages[k];
                                            if (buttonImage.src.indexOf('page0') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/xyHsbDk.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/HTmeB5H.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/loGYUlS.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/vPtQEjp.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/U7ZteJs.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/8UR9Yhn.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/bBzcVyr.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/RBoTXTL.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page1') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/E6tLMed.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/muPaovt.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/vYaBHHh.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/99VMjsw.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/0pLCCmB.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/ZYXRnmk.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/pDCV4gA.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/E7UJbND.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page2') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/TBhi5To.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/TXROBO3.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/9hJDNVD.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/XjaCElo.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/X9CD9wa.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/VmiauL2.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/c1YQ9SQ.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/140z8UJ.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page3') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/0hyAkOU.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/nR4YZi8.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/hhqTHip.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/hOl39Vq.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/FNX1xQJ.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/hKcq360.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/oVGawRo.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/hYJkxpT.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page4') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/3keYJWh.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/YLiBU5R.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/yXpY9j5.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/gScdzjm.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/9ajtmom.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/tMldxmT.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/eE7KOEv.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/0crvRhc.png 2x');
                                                }
                                            }
                                            else if (buttonImage.src.indexOf('page5') != -1) {
                                                if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/1lWBjDE.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/9zC41E2.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/JLl9PsD.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/l5nwC1m.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/eQTSAI4.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/BgxNpbQ.png 2x');
                                                }
                                                else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                    buttonImage.src = 'https://i.imgur.com/ZPJDx7H.png';
                                                    buttonImage.setAttribute('srcset', 'https://i.imgur.com/DHV3qOZ.png 2x');
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                var newest = repliesWrapper.getElementsByClassName('newest');
                if ((newest != null) && (newest.length) && (newest.length > 0)) {
                    for (i = 0; i < newest.length; i++) {
                        var newestChild = newest[i];
                        if ((newestChild != null) && (newestChild.children)) {
                            var childImages = newestChild.children;
                            if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                for (var k = 0; k < childImages.length; k++) {
                                    var buttonImage = childImages[k];
                                    if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/gt0tVDJ.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/W3fuz9v.png 2x');
                                    }
                                    else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/lccL9Lf.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/perrYx0.png 2x');
                                    }
                                    else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/uKi5wUE.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/jAtP5aA.png 2x');
                                    }
                                    else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                        buttonImage.src = 'https://i.imgur.com/VczR3zU.png';
                                        buttonImage.setAttribute('srcset', 'https://i.imgur.com/348mgw6.png 2x');
                                    }
                                }
                            }
                        }
                    }
                }

            }

            var threadsContainer = document.getElementById('threadsContainer');
            if (threadsContainer != null) {
                

            }

            localTabImages();
        }, 600);
    }
    localTabImages();

})();
