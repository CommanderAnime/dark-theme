﻿(function () {

    var darkThemeEnabled = false;

    chrome.storage.local.get(['darkThemeEnabled'], function (result) {
        darkThemeEnabled = result.darkThemeEnabled;
        if (result.darkThemeEnabled) {
            document.head.insertAdjacentHTML('beforeend',
                '<link rel="stylesheet" type="text/css" href="' +
                chrome.runtime.getURL("styles.css") + '">'
            );

            setTimeout(function () {
                var images = null;

                var shopTab = document.getElementById('shopTab');
                if ((shopTab != null) && (shopTab.children != null)) {
                    images = shopTab.children;
                    // selected
                    images[0].src = 'https://i.imgur.com/2qFpkHm.png';
                    images[0].setAttribute('srcset', 'https://i.imgur.com/1fo1swc.png 2x');
                    // deselected
                    images[1].src = 'https://i.imgur.com/eh54AM5.png';
                    images[1].setAttribute('srcset', 'https://i.imgur.com/ii1hiDi.png 2x');
                }

                var newsTab = document.getElementById('newsTab');
                if ((newsTab != null) && (newsTab.children != null)) {
                    images = newsTab.children;
                    // selected
                    images[0].src = 'https://i.imgur.com/nY24pGb.png';
                    images[0].setAttribute('srcset', 'https://i.imgur.com/TdUMEub.png 2x');
                    // deselected
                    images[1].src = 'https://i.imgur.com/P9GNdLY.png';
                    images[1].setAttribute('srcset', 'https://i.imgur.com/2Lxx97q.png 2x');
                }

                var gameTab = document.getElementById('gameTab');
                if ((gameTab != null) && (gameTab.children != null)) {
                    images = gameTab.children;
                    // selected
                    images[0].src = 'https://i.imgur.com/Cm3LdpY.png';
                    images[0].setAttribute('srcset', 'https://i.imgur.com/iNJkC5K.png 2x');
                    // deselected
                    images[1].src = 'https://i.imgur.com/3arvoW6.png';
                    images[1].setAttribute('srcset', 'https://i.imgur.com/fh8BsBn.png 2x');
                }

                var forumTab = document.getElementById('forumTab');
                if ((forumTab != null) && (forumTab.children != null)) {
                    images = forumTab.children;
                    // selected
                    images[0].src = 'https://i.imgur.com/QJFYaoc.png';
                    images[0].setAttribute('srcset', 'https://i.imgur.com/7UHh4qx.png 2x');
                    // deselected
                    images[1].src = 'https://i.imgur.com/pNwyIh4.png';
                    images[1].setAttribute('srcset', 'https://i.imgur.com/xE0cmuS.png 2x');
                }

                var garageTab = document.getElementById('garageTab');
                if ((garageTab != null) && (garageTab.children != null)) {
                    images = garageTab.children;
                    // selected
                    images[0].src = 'https://i.imgur.com/feqLi7b.png';
                    images[0].setAttribute('srcset', 'https://i.imgur.com/yq8g7r9.png 2x');
                    // deselected
                    images[1].src = 'https://i.imgur.com/kzaSP75.png';
                    images[1].setAttribute('srcset', 'https://i.imgur.com/aRgI9y4.png 2x');
                }

                var appStoreSnippet = document.getElementById('appStoreSnippet');
                if (appStoreSnippet != null) {
                    var imgAppStore = appStoreSnippet.children[0];
                    imgAppStore.src = 'https://vectr.com/commanderanime/e4j7fvcqk5.svg?width=640&height=186.67&select=e4j7fvcqk5page0';
                }

                var googlePlaySnippet = document.getElementById('googlePlaySnippet');
                if (googlePlaySnippet != null) {
                    var imgGooglePlay = googlePlaySnippet.children[0];
                    imgGooglePlay.src = 'https://vectr.com/commanderanime/c23SvBkgX7.svg?width=640&height=213.33&select=c23SvBkgX7page0';


                }
            }, 400);

            function localTabImages() {
                setTimeout(function () {
                    var newsPost54 = document.getElementById('newsPost-54');

                    if (newsPost54 != null) {
                        var imgNewsPost = newsPost54.getElementsByTagName('img')[1];
                        imgNewsPost.src = 'https://i.imgur.com/h9iV4He.png';
                        imgNewsPost.setAttribute('srcset', 'https://i.imgur.com/4lgXMG3.png 2x');
                    }

                    var newsPost29 = document.getElementById('newsPost-29');
                    if (newsPost29 != null) {
                        var imgNewsPost = newsPost29.getElementsByTagName('img')[1];
                        imgNewsPost.src = 'https://i.imgur.com/IyPANd4.png';
                        imgNewsPost.setAttribute('srcset', 'https://i.imgur.com/0Qt72LN.png 2x');
                    }

                    var newsPost39 = document.getElementById('newsPost-39');
                    if (newsPost39 != null) {
                        var imgNewsPost = newsPost39.getElementsByTagName('img')[1];
                        imgNewsPost.src = 'https://i.imgur.com/IyPANd4.png';
                        imgNewsPost.setAttribute('srcset', 'https://i.imgur.com/0Qt72LN.png 2x');
                    }

                    var newsPost25 = document.getElementById('newsPost-25');
                    if (newsPost25 != null) {
                        var content = newsPost25.getElementsByClassName('content')[0];
                        content.style.backgroundImage = "url('https://i.imgur.com/Q0VBA0I.png')";


                    }

                    var threadsWrapper = document.getElementById('threadsWrapper');
                    if (threadsWrapper != null) {
                        var ellipsis = threadsWrapper.getElementsByClassName('ellipsis');
                        if ((ellipsis != null) && (ellipsis.length) && (ellipsis.length > 0)) {
                            for (var i = 0; i < ellipsis.length; i++) {
                                var ellipsisImage = ellipsis[i].children[0];
                                ellipsisImage.src = 'https://i.imgur.com/pBtVKL2.png';
                                ellipsisImage.setAttribute('srcset', 'https://i.imgur.com/T3cQP4b.png 2x');
                            }
                        }

                        var others = threadsWrapper.getElementsByClassName('other');
                        if ((others != null) && (others.length) && (others.length > 0)) {
                            for (i = 0; i < others.length; i++) {
                                var otherChildren = others[i].children;
                                if ((otherChildren != null) && (otherChildren.length) && (otherChildren.length > 0)) {
                                    for (var j = 0; j < otherChildren.length; j++) {
                                        var childImages = null;
                                        var childDiv = otherChildren[j];
                                        if (childDiv.getAttribute("class").indexOf('selected') != -1) {
                                            childImages = childDiv.getElementsByTagName('img');
                                            if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                                for (var k = 0; k < childImages.length; k++) {


                                                }
                                            }
                                        }
                                        else {
                                            childImages = childDiv.getElementsByTagName('img');
                                            if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                                for (var k = 0; k < childImages.length; k++) {
                                                    var buttonImage = childImages[k];
                                                    if (buttonImage.src.indexOf('page0') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/xyHsbDk.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/HTmeB5H.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/loGYUlS.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/vPtQEjp.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/U7ZteJs.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/8UR9Yhn.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/bBzcVyr.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/RBoTXTL.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page1') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/E6tLMed.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/muPaovt.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/vYaBHHh.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/99VMjsw.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/0pLCCmB.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/ZYXRnmk.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/pDCV4gA.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/E7UJbND.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page2') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/TBhi5To.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/TXROBO3.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/0IvuZu0.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/XjaCElo.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/X9CD9wa.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/VmiauL2.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/c1YQ9SQ.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/140z8UJ.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page3') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/0hyAkOU.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/nR4YZi8.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/hhqTHip.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/hOl39Vq.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/FNX1xQJ.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/hKcq360.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/oVGawRo.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/hYJkxpT.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page4') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/3keYJWh.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/YLiBU5R.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/yXpY9j5.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/gScdzjm.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/9ajtmom.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/tMldxmT.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/eE7KOEv.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/0crvRhc.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page5') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/1lWBjDE.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/9zC41E2.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/JLl9PsD.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/l5nwC1m.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/eQTSAI4.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/BgxNpbQ.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/ZPJDx7H.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/DHV3qOZ.png 2x');
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        var newest = threadsWrapper.getElementsByClassName('newest');
                        if ((newest != null) && (newest.length) && (newest.length > 0)) {
                            for (i = 0; i < newest.length; i++) {
                                var newestChild = newest[i];
                                if ((newestChild != null) && (newestChild.children)) {
                                    var childImages = newestChild.children;
                                    if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                        for (var k = 0; k < childImages.length; k++) {
                                            var buttonImage = childImages[k];
                                            if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/gt0tVDJ.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/W3fuz9v.png 2x');
                                            }
                                            else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/lccL9Lf.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/perrYx0.png 2x');
                                            }
                                            else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/uKi5wUE.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/jAtP5aA.png 2x');
                                            }
                                            else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/VczR3zU.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/348mgw6.png 2x');
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }

                    var repliesWrapper = document.getElementById('repliesWrapper');
                    if (repliesWrapper != null) {
                        var backButton = repliesWrapper.getElementsByClassName('back');
                        if ((backButton != null) && (backButton.length) && (backButton.length > 0)) {
                            for (var i = 0; i < backButton.length; i++) {
                                var childImages = backButton[i].children;
                                if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                    for (var j = 0; j < childImages.length; j++) {
                                        var image = childImages[j];
                                        if (image.getAttribute("class").indexOf('standard') != -1) {
                                            image.src = 'https://i.imgur.com/mSo1QGD.png';
                                            image.setAttribute('srcset', 'https://i.imgur.com/3M7wayz.png 2x');
                                        }
                                        else if (image.getAttribute("class").indexOf('active') != -1) {
                                            image.src = 'https://i.imgur.com/6dflRS5.png';
                                            image.setAttribute('srcset', 'https://i.imgur.com/2GZxqBL.png 2x');
                                        }
                                    }
                                }
                            }
                        }

                        var oldestButton = repliesWrapper.getElementsByClassName('oldest');
                        if ((oldestButton != null) && (oldestButton.length) && (oldestButton.length > 0)) {
                            for (var i = 0; i < oldestButton.length; i++) {
                                var childImages = oldestButton[i].children;
                                if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                    for (var j = 0; j < childImages.length; j++) {
                                        var image = childImages[j];
                                        if (image.getAttribute("class").indexOf('selected active') != -1) {
                                            image.src = 'https://i.imgur.com/R8p4OFE.png';
                                            image.setAttribute('srcset', 'https://i.imgur.com/KYhm3ej.png 2x');
                                        }
                                        else if (image.getAttribute("class").indexOf('standard') != -1) {
                                            image.src = 'https://i.imgur.com/TKEmqY6.png';
                                            image.setAttribute('srcset', 'https://i.imgur.com/VolrKCn.png 2x');
                                        }
                                        else if (image.getAttribute("class").indexOf('active') != -1) {
                                            image.src = 'https://i.imgur.com/r3oXJXI.png';
                                            image.setAttribute('srcset', 'https://i.imgur.com/sN4CVCF.png 2x');
                                        }
                                        else if (image.getAttribute("class").indexOf('selected') != -1) {
                                            image.src = 'https://i.imgur.com/3ErO44k.png';
                                            image.setAttribute('srcset', 'https://i.imgur.com/b1wgI58.png 2x');
                                        }
                                    }
                                }
                            }
                        }

                        var ellipsis = repliesWrapper.getElementsByClassName('ellipsis');
                        if ((ellipsis != null) && (ellipsis.length) && (ellipsis.length > 0)) {
                            for (var i = 0; i < ellipsis.length; i++) {
                                var ellipsisImage = ellipsis[i].children[0];
                                ellipsisImage.src = 'https://i.imgur.com/pBtVKL2.png';
                                ellipsisImage.setAttribute('srcset', 'https://i.imgur.com/T3cQP4b.png 2x');
                            }
                        }

                        var others = repliesWrapper.getElementsByClassName('other');
                        if ((others != null) && (others.length) && (others.length > 0)) {
                            for (i = 0; i < others.length; i++) {
                                var otherChildren = others[i].children;
                                if ((otherChildren != null) && (otherChildren.length) && (otherChildren.length > 0)) {
                                    for (var j = 0; j < otherChildren.length; j++) {
                                        var childImages = null;
                                        var childDiv = otherChildren[j];
                                        if (childDiv.getAttribute("class").indexOf('selected') != -1) {
                                            childImages = childDiv.getElementsByTagName('img');
                                            if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                                for (var k = 0; k < childImages.length; k++) {


                                                }
                                            }
                                        }
                                        else {
                                            childImages = childDiv.getElementsByTagName('img');
                                            if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                                for (var k = 0; k < childImages.length; k++) {
                                                    var buttonImage = childImages[k];
                                                    if (buttonImage.src.indexOf('page0') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/xyHsbDk.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/HTmeB5H.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/loGYUlS.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/vPtQEjp.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/U7ZteJs.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/8UR9Yhn.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/bBzcVyr.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/RBoTXTL.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page1') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/E6tLMed.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/muPaovt.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/vYaBHHh.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/99VMjsw.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/0pLCCmB.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/ZYXRnmk.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/pDCV4gA.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/E7UJbND.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page2') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/TBhi5To.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/TXROBO3.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/0IvuZu0.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/XjaCElo.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/X9CD9wa.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/VmiauL2.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/c1YQ9SQ.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/140z8UJ.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page3') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/0hyAkOU.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/nR4YZi8.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/hhqTHip.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/hOl39Vq.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/FNX1xQJ.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/hKcq360.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/oVGawRo.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/hYJkxpT.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page4') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/3keYJWh.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/YLiBU5R.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/yXpY9j5.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/gScdzjm.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/9ajtmom.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/tMldxmT.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/eE7KOEv.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/0crvRhc.png 2x');
                                                        }
                                                    }
                                                    else if (buttonImage.src.indexOf('page5') != -1) {
                                                        if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/1lWBjDE.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/9zC41E2.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/JLl9PsD.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/l5nwC1m.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/eQTSAI4.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/BgxNpbQ.png 2x');
                                                        }
                                                        else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                            buttonImage.src = 'https://i.imgur.com/ZPJDx7H.png';
                                                            buttonImage.setAttribute('srcset', 'https://i.imgur.com/DHV3qOZ.png 2x');
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        var newest = repliesWrapper.getElementsByClassName('newest');
                        if ((newest != null) && (newest.length) && (newest.length > 0)) {
                            for (i = 0; i < newest.length; i++) {
                                var newestChild = newest[i];
                                if ((newestChild != null) && (newestChild.children)) {
                                    var childImages = newestChild.children;
                                    if ((childImages != null) && (childImages.length) && (childImages.length > 0)) {
                                        for (var k = 0; k < childImages.length; k++) {
                                            var buttonImage = childImages[k];
                                            if (buttonImage.getAttribute("class").indexOf('selected active') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/gt0tVDJ.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/W3fuz9v.png 2x');
                                            }
                                            else if (buttonImage.getAttribute("class").indexOf('standard') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/lccL9Lf.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/perrYx0.png 2x');
                                            }
                                            else if (buttonImage.getAttribute("class").indexOf('active') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/uKi5wUE.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/jAtP5aA.png 2x');
                                            }
                                            else if (buttonImage.getAttribute("class").indexOf('selected') != -1) {
                                                buttonImage.src = 'https://i.imgur.com/VczR3zU.png';
                                                buttonImage.setAttribute('srcset', 'https://i.imgur.com/348mgw6.png 2x');
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    localTabImages();
                }, 500);
            }
            localTabImages();
        }
    });

    var labReportElem = null;



    var target = document.getElementById('chat');
    const config = { attributes: true, childList: true, subtree: true };
    const callback = function (mutationsList, observer) {
        for (let mutation of mutationsList) {
            if (mutation.type === 'childList') {

                var playerNames = document.getElementsByTagName("svg");
                if ((playerNames != null) && (playerNames.length) && (playerNames.length > 0)) {
                    for (var i = 0; i < playerNames.length; i++) {
                        var playerName = playerNames[i];
                        var nameTexts = playerName.getElementsByTagName("text");
                        var parentDiv = playerName.parentElement;

                        if ((nameTexts != null) && nameTexts.length && !parentDiv.className.match(/\busername\b/)) {
                            if (nameTexts.length == 2) {
                                var nameText = nameTexts[0].textContent;
                                if (nameText != null) {
                                    var text1clone = nameTexts[0].cloneNode(true);
                                    var text2clone = nameTexts[1].cloneNode(true);

                                    switch (nameText) {
                                        // Moderators
                                        case "5am":
                                        case "revengexx1":
                                        case "george8888":
                                        case "Mud":
                                        case "rhak":
                                        case "captainahvong":
                                        case "Dalek-Buster":
                                        case "QuickNinja64":
                                        case "PurpleGnome":
                                        case "foxter":
                                        case "supervolcano":
                                        case "CryingLightning":
                                        case "Grey":
                                        case "Brawl":
                                        case "newthy32":
                                        case "Spiros04":
                                        case "CommanderAnime":
                                        case "YD109":
                                            text1clone.textContent = "Moderator";
                                            text2clone.textContent = "Moderator";
                                            break;
                                        // Retired Mods
                                        case "Chrome-Bolt":
                                        case "clayr":
                                        case "Henrik":
                                        case "Zero_Blade":
                                        case "ben314":
                                        case "danteallage":
                                        case "Kamikaze":
                                        case "lol69":
                                        case "rowr":
                                        case "TeamJ":
                                        case "Twinklepop":
                                        case "ZuperFly":
                                        case "Awesomer002":
                                        case "CamoKill":
                                        case "dcdeath":
                                        case "1BigBouie":
                                        case "MonkeysWithGuns":
                                        case "Avenger97":
                                        case "Buster321":
                                        case "jlynch60":
                                        case "moscles25":
                                        case "Scotto":
                                        case "shockwave44":
                                            text1clone.textContent = "Retired Mod";
                                            text2clone.textContent = "Retired Mod";
                                            break;
                                        // Mad Scientists
                                        case "purup":
                                        case "bbc":
                                        case "boll2":
                                            text1clone.textContent = "Mad Scientist";
                                            text2clone.textContent = "Mad Scientist";
                                            break;
                                        // George8888's alt
                                        case "LaikaClone02":
                                            text1clone.textContent = "George's alt";
                                            text2clone.textContent = "George's alt";
                                        // TTOC
                                        case "TTOC":
                                            text1clone.textContent = "★ 2020 ★";
                                            text2clone.textContent = "★ 2020 ★";
                                    }

                                    if (nameTexts[0].textContent != text1clone.textContent) {
                                        text1clone.setAttribute('y', '34');
                                        text2clone.setAttribute('y', '34');

                                        playerName.setAttribute('height', '70');
                                        playerName.appendChild(text1clone);
                                        playerName.appendChild(text2clone);
                                    }

                                    if (nameText == "TTOC") {
                                        var parentContainer = playerName.parentElement.parentElement.parentElement;
                                        var headerElms = parentContainer.getElementsByClassName("header");
                                        if ((headerElms != null) && (headerElms.length > 0)) {
                                            var headerText = "";
                                            for (var i = 0; i < headerElms.length; i++) {
                                                headerText = headerElms[i].textContent.toLowerCase();
                                                if (headerText.indexOf("ttoc") != -1) {
                                                    if (parentContainer.getAttribute("class").indexOf('ttoc') == -1) {
                                                        parentContainer.classList.add("ttoc");
                                                        labReportElem = parentContainer;

                                                        headerElms[i].style.fontFamily = "TankTrouble";
                                                        headerElms[i].style.fontSize = "1.1em";
                                                        headerElms[i].style.fontWeight = "normal";

                                                        if (!darkThemeEnabled) {
                                                            headerElms[i].parentElement.style.border = "#775820 2px solid";
                                                            headerElms[i].parentElement.style.backgroundColor = "#86692a";

                                                            headerElms[i].parentElement.onmouseover = function () {
                                                                this.style.backgroundColor = "##775820";
                                                            }
                                                            headerElms[i].parentElement.onmouseleave = function () {
                                                                this.style.backgroundColor = "#86692a";
                                                            }
                                                        }
                                                        headerElms[i].innerHTML = '<a href="' + 'https://samc7.github.io/TTOC/' + '" target="_blank">' + headerElms[i].textContent + '</a>';
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (nameText == "george8888") {
                                        var parentContainer = playerName.parentElement.parentElement.parentElement;
                                        var headerElms = parentContainer.getElementsByClassName("header");
                                        if ((headerElms != null) && (headerElms.length > 0)) {
                                            var headerText = "";
                                            for (var i = 0; i < headerElms.length; i++) {
                                                headerText = headerElms[i].textContent.toLowerCase();
                                                if (headerText.indexOf("lab report") != -1) {
                                                    if (parentContainer.getAttribute("class").indexOf('labreport') == -1) {
                                                        parentContainer.classList.add("labreport");
                                                        labReportElem = parentContainer;

                                                        headerElms[i].style.fontFamily = "TankTrouble";
                                                        headerElms[i].style.fontSize = "1.1em";
                                                        headerElms[i].style.fontWeight = "normal";

                                                        if (!darkThemeEnabled) {
                                                            headerElms[i].parentElement.style.border = "#acb6d0 2px solid";
                                                            headerElms[i].parentElement.style.backgroundColor = "#ced4e5";

                                                            headerElms[i].parentElement.onmouseover = function () {
                                                                this.style.backgroundColor = "#acb6d0";
                                                            }
                                                            headerElms[i].parentElement.onmouseleave = function () {
                                                                this.style.backgroundColor = "#ced4e5";
                                                            }
                                                        }

                                                        var vol = headerText.substring(headerText.indexOf('volume') + 7, headerText.indexOf(','));
                                                        var issue = headerText.substring(headerText.indexOf('issue') + 6);

                                                        headerElms[i].innerHTML = '<a href="' + 'https://bit.ly/TLR_V' + vol + '_I' + issue + '" target="_blank">' + headerElms[i].textContent + '</a>';
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else {
                                if ((parentDiv != null) && parentDiv.className.match(/\bchatMessage\b/)) {
                                    var nameTexts = playerName.getElementsByTagName("text");
                                    if ((nameTexts != null) && nameTexts.length && (nameTexts.length > 2)) {
                                        var nameText = nameTexts[0].textContent;
                                        if (nameText != null) {
                                            var name = nameTexts[0].textContent.replace(":", "");
                                            if (name != "Welcome") {

                                                var preWidth = nameTexts[0].clientWidth;

                                                switch (name) {
                                                    // Moderators
                                                    case "revengexx1":
                                                    case "george8888":
                                                    case "Mud":
                                                    case "rhak":
                                                    case "captainahvong":
                                                    case "Dalek-Buster":
                                                    case "QuickNinja64":
                                                    case "PurpleGnome":
                                                    case "foxter":
                                                    case "supervolcano":
                                                    case "CryingLightning":
                                                    case "Grey":
                                                    case "Brawl":
                                                    case "newthy32":
                                                    case "Spiros04":
                                                    case "CommanderAnime":
                                                    case "YD109":
                                                        nameTexts[0].textContent = name + " (Mod): ";
                                                        nameTexts[1].textContent = name + " (Mod): ";
                                                        break;
                                                    // Mad Scientists
                                                    case "purup":
                                                    case "bbc":
                                                    case "boll2":
                                                        nameTexts[0].textContent = name + " (Dev): ";
                                                        nameTexts[1].textContent = name + " (Dev): ";
                                                        break;
                                                    // Sam username fix
                                                    case "5am":
                                                        nameTexts[0].textContent = "Sam (Mod):";
                                                        nameTexts[1].textContent = "Sam (Mod):";
                                                        break;
                                                }

                                                htmlChatLink(nameTexts);

                                                var postWidth = nameTexts[0].clientWidth;
                                                if (preWidth != postWidth) {

                                                    var tempTextContent = nameTexts[0].textContent;
                                                    nameTexts[0].textContent = '_ ' + tempTextContent;
                                                    postWidth = nameTexts[0].clientWidth;
                                                    nameTexts[0].textContent = tempTextContent;

                                                    var diff = parseFloat((postWidth - preWidth) + "");

                                                    var xVal = 0.0;
                                                    var doModX = true;

                                                    for (var j = 2; j < nameTexts.length; j++) {
                                                        try {
                                                            xVal = parseFloat(nameTexts[j].getAttribute("x"));
                                                        }
                                                        catch {
                                                            xVal = 0.0;
                                                        }
                                                        if ((xVal > 1) && doModX) {
                                                            nameTexts[j].setAttribute('x', xVal + diff);
                                                        }
                                                        else {
                                                            doModX = false;
                                                        }
                                                    }

                                                    try {
                                                        xVal = parseFloat(playerName.getAttribute("width"));
                                                    }
                                                    catch {
                                                        xVal = 0.0;
                                                    }
                                                    if (xVal > 1) {
                                                        playerName.setAttribute("width", xVal + diff);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (labReportElem != null) {
                        if (labReportElem.getAttribute("class").indexOf('labreport') == -1) {
                            labReportElem.classList.add("labreport");
                        }
                    }
                }

            }
        }
    };

    const observer = new MutationObserver(callback);
    observer.observe(target, config);

    function htmlChatLink(nameTexts) {
        for (var i = 2; i < nameTexts.length; i = i + 2) {
            if ((nameTexts[i].textContent.indexOf("https://") == 0 || nameTexts[i].textContent.indexOf(".com") != -1 || nameTexts[i].textContent.indexOf(".ly") != -1 || nameTexts[i].textContent.indexOf(".org") != -1 || nameTexts[i].textContent.indexOf(".net") != -1) && (nameTexts[i].parentElement.tagName != 'a')) {
                var msgUrl = nameTexts[i].textContent;
                if (nameTexts[i].textContent.indexOf("https:") != 0) {
                    msgUrl = 'https://' + msgUrl;
                }

                var oHtml1 = nameTexts[i].outerHTML;
                oHtml1 = '<a href="' + msgUrl + '" target="_blank">' + oHtml1 + '</a>';
                nameTexts[i].outerHTML = oHtml1;

                var oHtml2 = nameTexts[i + 1].outerHTML;
                oHtml2 = '<a href="' + msgUrl + '" target="_blank">' + oHtml2 + '</a>';
                nameTexts[i + 1].outerHTML = oHtml2;
            }

        }
    }

    //EXPERIMENTAL VSync script
    var oldURL = "";
    var currentURL = window.location.href;
    function checkURLchange(currentURL) {
        if (currentURL != oldURL) {
            var paras = document.getElementsByClassName('vsync_script');
            while (paras[0]) {
                paras[0].parentNode.removeChild(paras[0]);
            }
            if (window.location.href.endsWith(".com/game" || ".com")) {
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.className = 'vsync_script';
                script.text =
                    'if (!window.requestAnimationFrame) {\n' +
                    '    window.requestAnimationFrame =\n' +
                    '        window.mozRequestAnimationFrame ||\n' +
                    '        window.webkitRequestAnimationFrame;\n' +
                    '}\n' +
                    'var t = [];\n' +
                    'function animate(now) {\n' +
                    '    t.unshift(now);\n' +
                    '    if (t.length > 10) {\n' +
                    '        var t0 = t.pop();\n' +
                    '        var fps = Math.floor(1000 * 10 / (now - t0));\n' +
                    '        if (fps >= 30) {\n' +
                    '            GameManager.getGame().time.desiredFps = fps;\n' +
                    '        } else {\n' +
                    '            GameManager.getGame().time.desiredFps = 30;\n' +
                    '        }\n' +
                    '    }\n' +
                    '    window.requestAnimationFrame(animate);\n' +
                    '}\n' +
                    'window.requestAnimationFrame(animate);\n';
                document.getElementsByTagName('head')[0].appendChild(script);
            }
            if (window.location.href.toLowerCase().indexOf("game") === -1) {
                var paras2 = document.getElementsByClassName('vsync_script');

                while (paras2[0]) {
                    paras2[0].parentNode.removeChild(paras2[0]);
                }
            }
            oldURL = currentURL;
        }

        oldURL = window.location.href;
        setTimeout(function () {
            checkURLchange(window.location.href);
        }, 2000);
    }
    checkURLchange();

    document.onreadystatechange = function () {
        var currentURL = (window.location.href);
        function launchVSync(test1) {
            if (currentURL = "https://beta.tanktrouble.com/") {
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.className = 'vsync_script';
                script.text =
                    'if (!window.requestAnimationFrame) {\n' +
                    '    window.requestAnimationFrame =\n' +
                    '        window.mozRequestAnimationFrame ||\n' +
                    '        window.webkitRequestAnimationFrame;\n' +
                    '}\n' +
                    'var t = [];\n' +
                    'function animate(now) {\n' +
                    '    t.unshift(now);\n' +
                    '    if (t.length > 10) {\n' +
                    '        var t0 = t.pop();\n' +
                    '        var fps = Math.floor(1000 * 10 / (now - t0));\n' +
                    '        if (fps >= 30) {\n' +
                    '            GameManager.getGame().time.desiredFps = fps;\n' +
                    '        } else {\n' +
                    '            GameManager.getGame().time.desiredFps = 30;\n' +
                    '        }\n' +
                    '    }\n' +
                    '    window.requestAnimationFrame(animate);\n' +
                    '}\n' +
                    'window.requestAnimationFrame(animate);\n';
                document.getElementsByTagName('head')[0].appendChild(script);
            }
        }
        if (currentURL = "https://beta.tanktrouble.com/") {
            launchVSync();
        }
    }

    function fixServerLocation() {
        setTimeout(function () {

            document.onload = function () { window.name = ""; };
            if ($(".admin.chatLog").find(".section").length > 0) {
                var section = ($(".admin.chatLog").find(".section"));
                if (typeof section !== 'undefined') {
                    //search is closed in

                    var chatMessages = section.find('.chatMessage.listItem');
                    if (typeof chatMessages !== 'undefined' && chatMessages.length > 0) {
                        chatMessages.each(function () {
                            var details = $(this).find('.details');
                            if (typeof details !== 'undefined' && details.length > 0) {
                                var currentHtmlText = details.first().html();
                                var htmlText = details.first().html();

                                function openPlayerStats() {
                                    var searchBar = $('#adminPlayerLookupInput');
                                    if (typeof searchBar !== 'undefined') {
                                        searchBar.val(name);
                                    }
                                }
                                $('.username.adminLookup').click(function () {
                                    if (!this.hasAttribute("onclick")) {
                                        var name = "";
                                        var searchBar = "";
                                        this.setAttribute("onclick", "window.name = this.innerText; window.searchBar = $('#adminPlayerLookupInput'); searchBar.val(name);");
                                    }
                                });

                                htmlText = htmlText.replace("us-east1-mp2", "Newark");
                                htmlText = htmlText.replace("us-east1-mp1", "Old Newark");
                                htmlText = htmlText.replace("us-east1-mp", "Discontinued Newark");
                                htmlText = htmlText.replace("eu-west1-mp1", "London");
                                htmlText = htmlText.replace("eu-west1-mp", "Discontinued London");
                                htmlText = htmlText.replace("asia-central1-mp1", "Singapore");
                                htmlText = htmlText.replace("asia-central1-mp", "Discontinued Singapore");
                                htmlText = htmlText.replace("us-south1-mp1", "Dallas");
                                htmlText = htmlText.replace("us-east2-mp1", "Atlanta");
                                htmlText = htmlText.replace("us-west1-mp1", "Fremont");
                                htmlText = htmlText.replace("australia-east1-mp1", "Sydney");

                                var chatPlayerName = document.getElementsByClassName('username adminLookup');

                                if (currentHtmlText !== htmlText) {
                                    details.first().html(htmlText);
                                }
                            }
                        });
                    }
                }
            }
            fixServerLocation();
        }, 900);
    }
    fixServerLocation();

    function fixChatSendError() {
        setTimeout(function () {
            var chatForm = $("#chat").children(".content").find('form');
            if (typeof chatForm !== 'undefined') {
                $(chatForm).attr("style", "background-color:''")
            }
            var chatInput = $("#chat").children(".content").find(':input');
            if (typeof chatInput !== 'undefined') {
                if (chatInput.is(':disabled')) {
                    $(chatInput).prop("disabled", false);
                }
            }

            fixChatSendError();
        }, 1700);
    }
    fixChatSendError();

    function ThemedBanners() {
        setTimeout(function () {

            var d = new Date();
            var n = d.getMonth() + 1 //Current month
            var start = new Date(d.getFullYear(), 0, +1); //Full year
            var diff = d - start; //Finds ms in a year
            var oneDay = 1000 * 60 * 60 * 24; //Finds seconds in a day
            var day = Math.floor(diff / oneDay); //Calculates diff / oneDay to find current day of the year

            var premiumId = document.getElementsByClassName("premium")[0];

            //Christmas
            if ((n == 12) && (day <= 359) && (day >= 335)) {
                var bodyId = document.getElementsByTagName("body")[0].id;
                if (bodyId != null) {
                    if (premiumId != null) {
                        //Premium Christmas
                        document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/NCPuVXg.png)';
                        document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/NCPuVXg.png)';
                    }
                    if (!$("body").hasClass("premium")) {
                        if (darkThemeEnabled) {
                            //Dark Christmas
                            document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/LBXKi8S.png)';
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/LBXKi8S.png)';
                            document.getElementById("navigation").style.backgroundSize = '20%';
                        } else {
                            //Light Christmas
                            document.getElementById("topBanner").style["backgroundImage"] = "url('https://i.imgur.com/1KmoigE.png')";
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style["backgroundImage"] = "url('https://i.imgur.com/1KmoigE.png')";
                            document.getElementById("navigation").style.backgroundSize = '20%';

                        }
                    }
                }
            }


            //July 4th
            else if ((n == 7) && (day <= 188) && (day >= 185)) {
                var bodyId = document.getElementsByTagName("body")[0].id;
                if (bodyId != null) {
                    if (premiumId != null) {
                        //Premium American Independence Day
                        document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/L75blzb.png)';
                        document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/L75blzb.png)';
                    }
                    if (!$("body").hasClass("premium")) {
                        if (darkThemeEnabled) {
                            //Dark American Independence Day
                            document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/vfNoaTG.png)';
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/vfNoaTG.png)';
                            document.getElementById("navigation").style.backgroundSize = '20%';
                        } else {
                            //Light American Independence Day
                            document.getElementById("topBanner").style["backgroundImage"] = "url('https://i.imgur.com/i3ncVla.png')";
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style["backgroundImage"] = "url('https://i.imgur.com/i3ncVla.png')";
                            document.getElementById("navigation").style.backgroundSize = '20%';

                        }
                    }
                }
            }


            //Thanksgiving
            else if ((n == 11) && (day <= 333) && (day >= 327)) {
                var bodyId = document.getElementsByTagName("body")[0].id;
                if (bodyId != null) {
                    if (premiumId != null) {
                        //Premium Thanksgiving
                        document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/IusCx5B.png)';
                        document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/IusCx5B.png)';
                    }
                    if (!$("body").hasClass("premium")) {
                        if (darkThemeEnabled) {
                            //Dark Thanksgiving
                            document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/IhMZ240.png)';
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/IhMZ240.png)';
                            document.getElementById("navigation").style.backgroundSize = '20%';
                        } else {
                            //Light Thanksgiving
                            document.getElementById("topBanner").style["backgroundImage"] = "url('https://i.imgur.com/xO9nibE.png')";
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style["backgroundImage"] = "url('https://i.imgur.com/xO9nibE.png')";
                            document.getElementById("navigation").style.backgroundSize = '20%';

                        }
                    }
                }
            }


            //Halloween
            else if (n == 10) {
                var bodyId = document.getElementsByTagName("body")[0].id;
                if (bodyId != null) {
                    if (premiumId != null) {
                        //Premium Halloween
                        document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/ijbmf14.png)';
                        document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/ijbmf14.png)';
                    }
                    if (!$("body").hasClass("premium")) {
                        if (darkThemeEnabled) {
                            //Dark Halloween
                            document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/LOs0DLi.png)';
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/LOs0DLi.png)';
                            document.getElementById("navigation").style.backgroundSize = '20%';
                        } else {
                            //Light Halloween
                            document.getElementById("topBanner").style["backgroundImage"] = "url('https://i.imgur.com/KdxIAlF.png')";
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '20%';
                            document.getElementById("navigation").style["backgroundImage"] = "url('https://i.imgur.com/KdxIAlF.png')";
                            document.getElementById("navigation").style.backgroundSize = '20%';

                        }
                    }
                }
            }
            else {
                var bodyId = document.getElementsByTagName("body")[0].id;
                if (bodyId != null) {
                    if (premiumId != null) {
                        //Premium Default
                        document.getElementById("topBanner").style.backgroundImage = 'url(https://cdn-beta.tanktrouble.com/RELEASE-2019-03-28-01/assets/images/header/backgroundPremium.png)';
                        document.getElementById("topBanner").style.backgroundSize = '20%';
                        document.getElementById("navigation").style.backgroundImage = "url('https://cdn-beta.tanktrouble.com/RELEASE-2019-03-28-01/assets/images/header/backgroundPremium.png')";
                        document.getElementById("navigation").style.backgroundSize = '20%';
                    }
                    if (!$("body").hasClass("premium")) {
                        if (darkThemeEnabled) {
                            //Dark Default
                            document.getElementById("topBanner").style.backgroundImage = 'url(https://i.imgur.com/j09ZSI5.png)';
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '10%';
                            document.getElementById("navigation").style.backgroundImage = 'url(https://i.imgur.com/j09ZSI5.png)';
                            document.getElementById("navigation").style.backgroundSize = '10%';
                        } else {
                            //Light Default
                            document.getElementById("topBanner").style["backgroundImage"] = "url('https://cdn-beta.tanktrouble.com/RELEASE-2019-10-04-01/assets/images/header/background.png')";
                            document.getElementById("topBanner").style.height = '85px';
                            document.getElementById("topBanner").style.backgroundSize = '10%';
                            document.getElementById("navigation").style["backgroundImage"] = "url('https://cdn-beta.tanktrouble.com/RELEASE-2019-10-04-01/assets/images/header/background.png')";
                            document.getElementById("navigation").style.backgroundSize = '10%';
                        }
                    }
                }
            }

            ThemedBanners();
        }, 2000);
    }
    ThemedBanners();

    function chatLogCopyMsg() {
        setTimeout(function () {
            document.onload = function () { window.name = ""; };
            if ($(".admin.chatLog").find(".section").length > 0) {
                var section = ($(".admin.chatLog").find(".section"));
                if (typeof section !== 'undefined') {
                    var chatLogChatMessages = $('.message');
                    if (typeof chatLogChatMessages !== 'undefined') {
                        chatLogChatMessages.click(function () {
                            if (typeof this.getAttribute("onclick") != 'undefined') {
                                var chatLogMsg = "";
                                this.setAttribute("onclick", "this.style.fontWeight = 'bold'; window.chatLogMsg = this.innerText; var dummy = $('<input>').val(chatLogMsg).appendTo('body').select(); document.execCommand('copy'); setTimeout(function(){ dummy.remove(); }, 100);");
                            }
                        });
                    }
                }
            }
            var adminLookupDT = $(".admin.playerLookup").children('div')[1];
            if (typeof adminLookupDT !== 'undefined') {
                var adminLookupChildDiv = adminLookupDT.children[1]
                if (typeof adminLookupChildDiv !== 'undefined') {
                    var adminLookupChildTable = adminLookupChildDiv.children[1].firstElementChild;
                    if (typeof adminLookupChildTable !== 'undefined') {
                        var copyAttribute = $(adminLookupChildDiv).find("tr");
                        if (typeof copyAttribute !== 'undefined') {
                            var adminLookupClipboard = "";
                            copyAttribute.click(function () {
                                if (typeof this.getAttribute("onclick") != 'undefined') {
                                    this.setAttribute("onclick", "this.style.fontWeight = 'bold'; window.adminLookupClipboard = this.innerText; var dummy = $('<input>').val(adminLookupClipboard).appendTo('body').select(); document.execCommand('copy'); setTimeout(function(){ dummy.remove(); }, 100);");
                                }
                            });
                        }


                    }

                }

            }


            chatLogCopyMsg();
        }, 1800);
    }
    chatLogCopyMsg();

    function addNewsPost() {
        setTimeout(function () {
            var newsPosts = document.getElementById('newsPostsWrapper');
            if ((newsPosts != null) && (newsPosts.children != null) && (newsPosts.children.length > 0)) {
                var firstNewsPost = newsPosts.children[0];
                if (firstNewsPost.id != 'darkThemeNewsPost') {
                    var newNode = document.createElement('div');
                    newNode.id = 'darkThemeNewsPost';
                    newNode.setAttribute('class', 'newsPost standard');

                    var newsPostHTML = '';

                    if (!darkThemeEnabled) {
                        newsPostHTML +=
                            '<style>' +
                            '#darkThemeNewsPost .wrapper .content .story {' +
                            'background-color: #bbbbbb;' +
                            'border-radius: 5px;' +
                            'padding: 1px 10px 1px 10px;' +
                            'clear: both;' +
                            '}' +
                            '#darkThemeNewsPost .wrapper .content img {' +
                            'float: right;' +
                            'margin: 0 20px 10px 40px;' +
                            '}' +
                            '</style>';
                    }

                    newsPostHTML +=
                        '<div class="wrapper">' +
                        '  <div class="header">' +
                        '    <div class="title">Dark Theme News and Changelog</div>' +
                        '    <div class="time">2020-05-11</div>' +
                        '  </div>' +
                        '  <div class="content">' +
                        '    <img src=https://i.imgur.com/JiyevQv.png" srcset="https://i.imgur.com/MBfXMIk.png 2x">' +
                        '    <p>Give TankTrouble a new look with this smooth and coherent dark theme.</p>' +
                        '    <p>The extension is developed and provided by CommanderAnime. Download the extension on the <a href="https://chrome.google.com/webstore/detail/dark-theme-for-tank-troub/iaahklbbofakekcbhbjnpjbgaadhedhm" target="_blank">Chrome Webshop.</a> Customise the extension to your preference by downloading the newest version of the open-source material from the <a href="https://github.com/CommanderAnime/dark-theme" target="_blank">GitHub page.</a></p>' +
                        '    <p>Have any complaints, ideas, found a bug or want to comment on it? Leave a message in the <a href="https://docs.google.com/forms/d/1nT2jqe4iPtF9QtI21uddHcSC6w7ky1eVQJEN0G72ups/edit" target="_blank">Google form!</a></p>' +
                        '    <div class="story">' +
                        '      <p>What\'s new in version 0.3.6?</p>' +
                        '      <ul>' +
                        '        <li>VSync! The game now adjusts to high-framerate monitors, so you can play on +60 hertz (60 being the default), all the way up to 240 hz!</li>' +
                        '        <li>Hyperlinks in chat. All messages containing .com, .net, .org, .ly and https:// will be hyperlinked</li>' +
                        '        <li>Typing an illegal character in the chat will reset the chat, so you no longer have to reload the page due to the infinite loading bar</li>' +
                        '        <li>Backend fixes to (hopefully) decrease lag by replacing setTimeout with a mutationObserver</li>' +
                        '        <li>Misc backend fixes</li>' +
                        '        <li>Changes to some CSS</li>' +
                        '      </ul>' +
                        '    </div>' +
                        '  </div>' +
                        '</div>';


                    newNode.innerHTML = newsPostHTML;

                    newsPosts.insertBefore(newNode, newsPosts.children[0]);
                }
            }

            addNewsPost();
        }, 250);
    }
    addNewsPost();

    setTimeout(function () {
        //console.clear();
        console.log('%cDARK THEME FOR TANK TROUBLE', 'font-weight: bold; background: linear-gradient(to bottom,#427fff36,#0014ab36); color: #ffffff; font-size: 35px; text-shadow: #00000059 0px 3px 4px; font-family: TankTrouble;');
        console.log('%cProvided by CommanderAnime ', 'color: #2b3aab; font-size: 13px');
        console.log('%cInstall on Chrome Webshop: www.bit.ly/darkThemeDownload ', 'color: #2b3aab; font-size: 10px');
        console.log('%cCustomize the extension on GitHub: www.bit.ly/darkThemeGitHub ', 'color: #2b3aab; font-size: 10px');
        console.log("%c  ", "background-image: url('https://i.imgur.com/gVtJTYh.png'); background-repeat: no-repeat; background-size: 88px 88px; font-size: 80px; position: sticky;", " ")
    }, 1100);

})();