var darkThemeId = '';

chrome.storage.local.get(['darkThemeEnabled'], function (result) {
    if (!result) {
        chrome.storage.local.set({ darkThemeEnabled: true }, function () {  });
    }
});

$(document).ready(function () {
    chrome.storage.local.get(['darkThemeEnabled'], function (result) {
        console.log('A: ' + result.darkThemeEnabled);
        if (!result.darkThemeEnabled) {
            $('#toggleBtn').button('toggle');
        }
    });

    chrome.management.getSelf(function (result) {
        darkThemeId = result.id;
    });

    $('#toggleBtn').on('click', function () {
        chrome.storage.local.get(['darkThemeEnabled'], function (result) {
            if (result.darkThemeEnabled) {
                chrome.storage.local.set({ darkThemeEnabled: false }, function () { });
            }
            else {
                chrome.storage.local.set({ darkThemeEnabled: true }, function () { });
            }

            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
            });
        });
    });
});